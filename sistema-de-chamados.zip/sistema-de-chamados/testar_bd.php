<?php
// Iniciar a sessão para mensagens de feedback
session_start();

$host = 'localhost'; 
$dbname = 'suporte'; 
$username = 'root'; 
$password = ''; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id_chamado'])) {
    $id_chamado = $_POST['id_chamado'];
    $status = $_POST['status'];
    $colaborador_id = $_POST['colaborador_id'];

    $sql = "UPDATE chamados SET status = ?, colaborador_id = ? WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    if ($stmt->execute([$status, $colaborador_id, $id_chamado])) {
        $_SESSION['message'] = "Chamado atualizado com sucesso!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Erro ao atualizar chamado.";
        $_SESSION['message_type'] = "danger";
    }

    header("Location: gerenciamento_chamados.php");
    exit();
}

$filter_status = isset($_GET['status']) ? $_GET['status'] : '';
$filter_criticidade = isset($_GET['criticidade']) ? $_GET['criticidade'] : '';

$sql = "SELECT * FROM chamados WHERE status LIKE ? AND criticidade LIKE ?";
$stmt = $pdo->prepare($sql);
$stmt->execute(["%$filter_status%", "%$filter_criticidade%"]);
$chamados = $stmt->fetchAll();
?>