CREATE DATABASE SISTEMA_DE_CHAMADOS
USE SISTEMA_DE_CHAMADOS

CREATE TABLE Clientes (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Telefone VARCHAR(15) NOT NULL
);

CREATE TABLE Colaboradores (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    Nome VARCHAR(100) NOT NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Telefone VARCHAR(15) NOT NULL
);

CREATE TABLE chamados (
    id_chamado INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente INT,
    descricao TEXT NOT NULL,
    criticidade ENUM('baixa', 'média', 'alta') DEFAULT 'baixa',
    status ENUM('aberto', 'em andamento', 'resolvido') DEFAULT 'aberto',
    data_abertura DATETIME DEFAULT CURRENT_TIMESTAMP,
    id_colaborador_responsavel INT NULL,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente) ON DELETE CASCADE,
    FOREIGN KEY (id_colaborador_responsavel) REFERENCES colaboradores(id_colaborador) ON DELETE SET NULL
);

