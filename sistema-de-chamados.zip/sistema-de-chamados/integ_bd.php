<?php
session_start();

$host = 'localhost'; 
$dbname = 'sistema_de_chamados'; 
$username = 'root'; 
$password = 'root'; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Receber os dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $telefone = $_POST['telefone'];

    // Validação
    if (empty($nome) || empty($email) || empty($telefone)) {
        $_SESSION['message'] = "Todos os campos são obrigatórios.";
        $_SESSION['message_type'] = "danger";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_SESSION['message'] = "E-mail inválido.";
        $_SESSION['message_type'] = "danger";
    } else {
        // Inserir no banco de dados
        $sql = "INSERT INTO clientes (nome, email, telefone) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        if ($stmt->execute([$nome, $email, $telefone])) {
            $_SESSION['message'] = "Cliente cadastrado com sucesso!";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Erro ao cadastrar cliente.";
            $_SESSION['message_type'] = "danger";
        }
    }

    header("Location: back_cadastro.php");
    exit();
}
?>